"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

const CustomCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const updatePosition = (e) => {
      setPosition({ x: e.clientX, y: e.clientY })
      if (!isVisible) setIsVisible(true)
    }

    const handleMouseLeave = () => {
      setIsVisible(false)
    }

    const handleMouseEnter = () => {
      setIsVisible(true)
    }

    window.addEventListener("mousemove", updatePosition)
    document.body.addEventListener("mouseleave", handleMouseLeave)
    document.body.addEventListener("mouseenter", handleMouseEnter)

    // Hide default cursor
    document.body.style.cursor = "none"

    return () => {
      window.removeEventListener("mousemove", updatePosition)
      document.body.removeEventListener("mouseleave", handleMouseLeave)
      document.body.removeEventListener("mouseenter", handleMouseEnter)

      // Restore default cursor
      document.body.style.cursor = "auto"
    }
  }, [isVisible])

  if (!isVisible) return null

  return (
    <>
      {/* Cursor dot */}
      <motion.div
        className="fixed top-0 left-0 w-4 h-4 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 z-[9999] pointer-events-none"
        style={{
          x: position.x - 8,
          y: position.y - 8,
        }}
        transition={{ type: "spring", stiffness: 1000, damping: 50 }}
      />

      {/* Among Us character following cursor */}
      <motion.div
        className="fixed top-0 left-0 w-10 h-10 z-[9998] pointer-events-none"
        style={{
          x: position.x - 20,
          y: position.y - 20,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        <img src="/amongus.svg" alt="Among Us cursor" className="w-full h-full" crossOrigin="anonymous" />
      </motion.div>
    </>
  )
}

export default CustomCursor
