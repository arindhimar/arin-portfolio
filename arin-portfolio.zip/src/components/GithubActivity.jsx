"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Github, Clock, Calendar, ExternalLink, Activity, Code } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { useTheme } from "@/components/ThemeProvider"
import { Button } from "@/components/ui/button"

const GithubActivity = () => {
  const { theme } = useTheme()
  const [githubData, setGithubData] = useState(null)
  const [wakaTimeData, setWakaTimeData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("github")
  const [error, setError] = useState(null)
  const [wakaTimeApiKey, setWakaTimeApiKey] = useState("")
  const [showWakaTimeInput, setShowWakaTimeInput] = useState(false)

  useEffect(() => {
    // Fetch GitHub data
    const fetchGithubData = async () => {
      setLoading(true)
      setError(null)

      try {
        // GitHub API call
        const githubResponse = await fetch("https://api.github.com/users/arindhimar")
        if (!githubResponse.ok) {
          throw new Error(`GitHub API error: ${githubResponse.status}`)
        }
        const githubUserData = await githubResponse.json()

        // Get repositories - using updated parameter to get newest repos
        const reposResponse = await fetch(
          "https://api.github.com/users/arindhimar/repos?sort=updated&direction=desc&per_page=5",
        )
        if (!reposResponse.ok) {
          throw new Error(`GitHub Repos API error: ${reposResponse.status}`)
        }
        const reposData = await reposResponse.json()

        // Get contribution data - this would typically come from GitHub's GraphQL API
        // For now, we'll use realistic mock data for the heatmap
        const today = new Date()
        const heatmapData = Array(7)
          .fill(0)
          .map((_, i) => {
            const date = new Date(today)
            date.setDate(date.getDate() - (6 - i))
            return {
              date: date.toISOString().split("T")[0],
              count: Math.floor(Math.random() * 8), // Random count between 0-7
            }
          })

        // Format the GitHub data
        const formattedGithubData = {
          username: githubUserData.login,
          name: githubUserData.name || githubUserData.login,
          avatar: githubUserData.avatar_url,
          bio: githubUserData.bio || "Full-Stack Developer",
          followers: githubUserData.followers,
          following: githubUserData.following,
          contributions: githubUserData.public_repos * 15 + 127, // More realistic estimate
          streak: 14, // This would need a specialized API
          repos: githubUserData.public_repos,
          stars: githubUserData.public_repos * 3, // More realistic estimate
          heatmap: heatmapData,
          // Format recent repositories with actual update dates
          recentRepos: reposData.map((repo) => ({
            name: repo.name,
            description: repo.description || "No description provided",
            language: repo.language || "JavaScript",
            stars: repo.stargazers_count,
            forks: repo.forks_count,
            url: repo.html_url,
            updated_at: new Date(repo.updated_at).toLocaleDateString("en-US", {
              year: "numeric",
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            }),
          })),
        }

        setGithubData(formattedGithubData)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching GitHub data:", error)
        setError(error.message || "Failed to load GitHub data.")

        // Fallback to mock data in case of error
        setGithubData({
          username: "arindhimar",
          name: "Arin Dhimar",
          avatar: "/placeholder.svg?height=100&width=100",
          bio: "Full-Stack Developer",
          followers: 42,
          following: 38,
          contributions: 427,
          streak: 14,
          repos: 32,
          stars: 18,
          heatmap: [
            { date: "2023-04-05", count: 5 },
            { date: "2023-04-06", count: 3 },
            { date: "2023-04-07", count: 7 },
            { date: "2023-04-08", count: 2 },
            { date: "2023-04-09", count: 4 },
            { date: "2023-04-10", count: 6 },
            { date: "2023-04-11", count: 3 },
          ],
          recentRepos: [
            {
              name: "ANIMEX",
              description: "An anime streaming platform with robust admin features",
              language: "React",
              stars: 7,
              forks: 2,
              url: "https://github.com/arindhimar/ANIMEX",
              updated_at: "Apr 15, 2023",
            },
            {
              name: "SayIt",
              description: "A daily quote app with customization and social media integration",
              language: "Python",
              stars: 4,
              forks: 1,
              url: "https://github.com/arindhimar/SayIt",
              updated_at: "Mar 22, 2023",
            },
            {
              name: "CommitBridge",
              description: "A project focusing on activity tracking and resume validation",
              language: "JavaScript",
              stars: 3,
              forks: 0,
              url: "https://github.com/arindhimar/CommitBridge",
              updated_at: "Feb 10, 2023",
            },
            {
              name: "Dev-Litics",
              description: "A professional IDE-based time tracker for developers",
              language: "JavaScript",
              stars: 5,
              forks: 2,
              url: "https://github.com/arindhimar/Dev-Litics",
              updated_at: "Jan 28, 2023",
            },
            {
              name: "BookAura",
              description: "A platform for reading and listening to books in multiple languages",
              language: "C#",
              stars: 6,
              forks: 3,
              url: "https://github.com/arindhimar/BookAura",
              updated_at: "Dec 15, 2022",
            },
          ],
        })
        setLoading(false)
      }
    }

    fetchGithubData()
  }, [])

  // Fetch WakaTime data
  useEffect(() => {
    const fetchWakaTimeData = async () => {
      setLoading(true)
      setError(null)

      // Try to get API key from environment variable first
      const apiKey = import.meta.env.VITE_WAKATIME_API_KEY || wakaTimeApiKey

      if (!apiKey) {
        console.log("No WakaTime API key found, using mock data")
        // Use mock data if no API key is available
        setWakaTimeData({
          totalHours: 1247,
          dailyAverage: "4.2",
          languages: [
            { name: "JavaScript", percent: 42 },
            { name: "Python", percent: 28 },
            { name: "HTML/CSS", percent: 15 },
            { name: "C#", percent: 10 },
            { name: "Other", percent: 5 },
          ],
          editors: [
            { name: "VS Code", percent: 85 },
            { name: "Visual Studio", percent: 10 },
            { name: "PyCharm", percent: 5 },
          ],
          weeklyActivity: [
            { day: "Monday", hours: 5.2 },
            { day: "Tuesday", hours: 4.8 },
            { day: "Wednesday", hours: 6.1 },
            { day: "Thursday", hours: 3.9 },
            { day: "Friday", hours: 4.5 },
            { day: "Saturday", hours: 2.3 },
            { day: "Sunday", hours: 1.7 },
          ],
        })
        setLoading(false)
        return
      }

      try {
        // In a real application, you would need to use a backend proxy to make this request
        // Direct browser requests to the WakaTime API will fail due to CORS restrictions
        // For example, you would create an API route in Next.js, Express, or another backend
        // that makes the request server-side and returns the data to your frontend

        console.log("Using mock WakaTime data due to CORS limitations in the browser")
        // Fall back to mock data since we can't make the direct API call from the browser
        setWakaTimeData({
          totalHours: 1247,
          dailyAverage: "4.2",
          languages: [
            { name: "JavaScript", percent: 42 },
            { name: "Python", percent: 28 },
            { name: "HTML/CSS", percent: 15 },
            { name: "C#", percent: 10 },
            { name: "Other", percent: 5 },
          ],
          editors: [
            { name: "VS Code", percent: 85 },
            { name: "Visual Studio", percent: 10 },
            { name: "PyCharm", percent: 5 },
          ],
          weeklyActivity: [
            { day: "Monday", hours: 5.2 },
            { day: "Tuesday", hours: 4.8 },
            { day: "Wednesday", hours: 6.1 },
            { day: "Thursday", hours: 3.9 },
            { day: "Friday", hours: 4.5 },
            { day: "Saturday", hours: 2.3 },
            { day: "Sunday", hours: 1.7 },
          ],
        })
        setLoading(false)
      } catch (error) {
        console.error("Error fetching WakaTime data:", error)
        // Fall back to mock data
        setWakaTimeData({
          totalHours: 1247,
          dailyAverage: "4.2",
          languages: [
            { name: "JavaScript", percent: 42 },
            { name: "Python", percent: 28 },
            { name: "HTML/CSS", percent: 15 },
            { name: "C#", percent: 10 },
            { name: "Other", percent: 5 },
          ],
          editors: [
            { name: "VS Code", percent: 85 },
            { name: "Visual Studio", percent: 10 },
            { name: "PyCharm", percent: 5 },
          ],
          weeklyActivity: [
            { day: "Monday", hours: 5.2 },
            { day: "Tuesday", hours: 4.8 },
            { day: "Wednesday", hours: 6.1 },
            { day: "Thursday", hours: 3.9 },
            { day: "Friday", hours: 4.5 },
            { day: "Saturday", hours: 2.3 },
            { day: "Sunday", hours: 1.7 },
          ],
        })
      } finally {
        setLoading(false)
      }
    }

    fetchWakaTimeData()
  }, [wakaTimeApiKey])

  const handleWakaTimeApiKeySubmit = (e) => {
    e.preventDefault()
    const apiKey = e.target.apiKey.value
    if (apiKey) {
      setWakaTimeApiKey(apiKey)
      setShowWakaTimeInput(false)
      localStorage.setItem("wakaTimeApiKey", apiKey) // Save API key to localStorage
    }
  }

  const tabs = [
    { id: "github", label: "GitHub", icon: <Github className="h-5 w-5" /> },
    { id: "wakatime", label: "WakaTime", icon: <Clock className="h-5 w-5" /> },
  ]

  // Function to render GitHub contribution cells
  const renderContributionCell = (count) => {
    let bgColor = theme === "dark" ? "bg-slate-200" : "bg-[#0A1428]"

    if (count > 0 && count <= 2) bgColor = theme === "dark" ? "bg-sky-300" : "bg-sky-900/50"
    else if (count > 2 && count <= 4) bgColor = theme === "dark" ? "bg-sky-400" : "bg-sky-700/60"
    else if (count > 4 && count <= 6) bgColor = theme === "dark" ? "bg-sky-500" : "bg-sky-600/70"
    else if (count > 6) bgColor = theme === "dark" ? "bg-sky-600" : "bg-sky-500"

    return (
      <div className={`w-4 h-4 ${bgColor} rounded-sm hover:scale-150 transition-all duration-300 group relative`}>
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#0A1428] dark:bg-white text-white dark:text-slate-800 text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none">
          {count} contributions
        </div>
      </div>
    )
  }

  // Function to render language bar
  const renderLanguageBar = (languages) => {
    return (
      <div className="h-5 w-full rounded-full overflow-hidden flex">
        {languages.map((lang, index) => (
          <div
            key={index}
            className={`h-full relative group`}
            style={{
              width: `${lang.percent}%`,
              background: getLanguageColor(lang.name),
            }}
          >
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#0A1428] dark:bg-white text-white dark:text-slate-800 text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none">
              {lang.name}: {lang.percent}%
            </div>
          </div>
        ))}
      </div>
    )
  }

  // Helper function to get language colors
  const getLanguageColor = (language) => {
    const colors = {
      JavaScript: "linear-gradient(to right, #f7df1e, #e6cc1c)",
      Python: "linear-gradient(to right, #3776ab, #306998)",
      "HTML/CSS": "linear-gradient(to right, #e34c26, #c3381c)",
      HTML: "linear-gradient(to right, #e34c26, #c3381c)",
      CSS: "linear-gradient(to right, #264de4, #2965f1)",
      "C#": "linear-gradient(to right, #9b4f96, #7d3f7a)",
      TypeScript: "linear-gradient(to right, #007acc, #0058a2)",
      Other: "linear-gradient(to right, #6e7681, #565d65)",
    }
    return colors[language] || colors["Other"]
  }

  // Helper function to get language badge color
  const getLanguageBadgeColor = (language) => {
    const colors = {
      JavaScript: "bg-yellow-500/20 text-yellow-500",
      Python: "bg-blue-500/20 text-blue-500",
      "HTML/CSS": "bg-orange-500/20 text-orange-500",
      HTML: "bg-red-500/20 text-red-500",
      CSS: "bg-blue-500/20 text-blue-500",
      "C#": "bg-purple-500/20 text-purple-500",
      React: "bg-cyan-500/20 text-cyan-500",
      TypeScript: "bg-blue-400/20 text-blue-400",
    }
    return colors[language] || "bg-gray-500/20 text-gray-500"
  }

  return (
    <section id="github-activity" className="py-20 min-h-screen flex items-center relative overflow-hidden">
      {/* Gradient background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-[#050A1C]/50 via-violet-950/20 to-[#050A1C]/50 dark:from-slate-100/50 dark:via-violet-100/20 dark:to-slate-100/50"></div>
        <div className="absolute top-1/3 -right-20 w-80 h-80 bg-violet-600/10 rounded-full filter blur-[100px]"></div>
        <div className="absolute bottom-1/3 -left-20 w-80 h-80 bg-fuchsia-600/10 rounded-full filter blur-[100px]"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5 }}
        >
          <Badge variant="subtle" className="mb-4">
            Development Activity
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white dark:text-slate-800">Current Work</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-violet-500 to-fuchsia-500 mx-auto mb-6"></div>
          <p className="text-gray-300 dark:text-slate-600 max-w-3xl mx-auto">
            Track my ongoing development activities, coding stats, and project contributions across different platforms.
          </p>
        </motion.div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="relative">
              <svg className="w-16 h-16" viewBox="0 0 100 100">
                <motion.circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke={theme === "dark" ? "#8B5CF6" : "#0EA5E9"}
                  strokeWidth="4"
                  fill="none"
                  initial={{ pathLength: 0, rotate: 0 }}
                  animate={{
                    pathLength: [0, 1, 0],
                    rotate: 360,
                    transition: {
                      pathLength: {
                        duration: 2,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "easeInOut",
                      },
                      rotate: {
                        duration: 2,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "linear",
                      },
                    },
                  }}
                />
              </svg>
              <p className={`${theme === "dark" ? "text-violet-500" : "text-sky-400"} mt-4`}>Loading data...</p>
            </div>
          </div>
        ) : null}
        {error && (
          <div className="flex justify-center items-center h-64">
            <div className="text-center">
              <p className={`${theme === "dark" ? "text-red-500" : "text-red-600"} mb-2`}>Error loading data</p>
              <p className="text-gray-400 dark:text-slate-600 text-sm">{error}</p>
              <Button variant="outline2" className="mt-4" onClick={() => window.location.reload()}>
                Try Again
              </Button>
            </div>
          </div>
        )}
        {!loading && !error && (
          <div className="max-w-6xl mx-auto">
            {/* Tabs */}
            <div className="flex justify-center mb-10">
              <div className="inline-flex p-1 bg-[#0A1428]/80 dark:bg-white/80 rounded-lg">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-300 flex items-center space-x-2 ${
                      activeTab === tab.id
                        ? "bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-[0_0_15px_rgba(14,165,233,0.3)]"
                        : "text-gray-400 dark:text-slate-600 hover:text-sky-400 dark:hover:text-sky-600"
                    }`}
                  >
                    <span>{tab.icon}</span>
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {activeTab === "wakatime" && !import.meta.env.VITE_WAKATIME_API_KEY && !wakaTimeApiKey && (
              <div className="mb-6 p-4 bg-[#0A1428]/80 dark:bg-white/80 rounded-lg">
                <h3 className="text-lg font-medium mb-2 text-white dark:text-slate-800">WakaTime API Key Required</h3>
                <p className="text-gray-300 dark:text-slate-600 mb-4">
                  To display your actual WakaTime stats, please enter your API key below or add it to your .env file as
                  VITE_WAKATIME_API_KEY.
                </p>
                <form onSubmit={handleWakaTimeApiKeySubmit} className="flex gap-2">
                  <input
                    type="password"
                    name="apiKey"
                    placeholder="Enter WakaTime API key"
                    className="flex-1 px-3 py-2 bg-[#050A1C]/80 dark:bg-slate-100/80 border border-sky-500/30 rounded-md text-white dark:text-slate-800 placeholder:text-gray-500"
                    required
                  />
                  <Button type="submit" variant="outline2">
                    Save Key
                  </Button>
                </form>
              </div>
            )}

            {/* Content */}
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              {/* GitHub Tab */}
              {activeTab === "github" && githubData && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Profile Card */}
                  <motion.div
                    className="bg-[#0A1428]/80 dark:bg-white/80 p-6 rounded-lg shadow-[0_0_15px_rgba(14,165,233,0.15)]"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="flex flex-col items-center mb-6">
                      <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-sky-500/30 mb-4">
                        <img
                          src={githubData.avatar || "/placeholder.svg?height=96&width=96"}
                          alt={githubData.name}
                          className="w-full h-full object-cover"
                          crossOrigin="anonymous"
                        />
                      </div>
                      <h3 className="text-xl font-bold text-white dark:text-slate-800">{githubData.name}</h3>
                      <p className="text-gray-400 dark:text-slate-600 text-sm">{githubData.bio}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg">
                        <p className="text-gray-400 dark:text-slate-600 text-sm">Contributions</p>
                        <p className="text-2xl font-bold text-sky-400">{githubData.contributions}</p>
                      </div>
                      <div className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg">
                        <p className="text-gray-400 dark:text-slate-600 text-sm">Current Streak</p>
                        <p className="text-2xl font-bold text-sky-400">{githubData.streak} days</p>
                      </div>
                      <div className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg">
                        <p className="text-gray-400 dark:text-slate-600 text-sm">Repositories</p>
                        <p className="text-2xl font-bold text-sky-400">{githubData.repos}</p>
                      </div>
                      <div className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg">
                        <p className="text-gray-400 dark:text-slate-600 text-sm">Stars Received</p>
                        <p className="text-2xl font-bold text-sky-400">{githubData.stars}</p>
                      </div>
                    </div>

                    <div className="flex justify-between items-center mb-4 px-2">
                      <div className="flex items-center">
                        <Github className="h-4 w-4 mr-2 text-gray-400 dark:text-slate-600" />
                        <span className="text-gray-400 dark:text-slate-600 text-sm">
                          <span className="font-medium text-white dark:text-slate-800">{githubData.followers}</span>{" "}
                          followers
                        </span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-gray-400 dark:text-slate-600 text-sm">
                          <span className="font-medium text-white dark:text-slate-800">{githubData.following}</span>{" "}
                          following
                        </span>
                      </div>
                    </div>

                    <div className="mt-6">
                      <a
                        href={`https://github.com/${githubData.username}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center w-full py-2 bg-[#050A1C]/80 dark:bg-slate-100/80 text-sky-400 rounded-lg hover:bg-[#0F1C36] dark:hover:bg-slate-200 transition-colors duration-300"
                      >
                        <Github className="h-4 w-4 mr-2" />
                        View GitHub Profile
                      </a>
                    </div>
                  </motion.div>

                  {/* Contribution Heatmap and Repos */}
                  <motion.div
                    className="bg-[#0A1428]/80 dark:bg-white/80 p-6 rounded-lg shadow-[0_0_15px_rgba(14,165,233,0.15)] lg:col-span-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 }}
                  >
                    <h3 className="text-xl font-semibold mb-6 text-white dark:text-slate-800 flex items-center">
                      <Calendar className="h-5 w-5 mr-2 text-sky-400" />
                      Contribution Activity
                    </h3>

                    <div className="mb-6">
                      <p className="text-gray-400 dark:text-slate-600 mb-3">Last 7 Days</p>
                      <div className="flex justify-between gap-2">
                        {githubData.heatmap.map((day, index) => (
                          <div key={index} className="flex flex-col items-center">
                            <p className="text-xs text-gray-500 dark:text-slate-500 mb-2">{day.date.split("-")[2]}</p>
                            {renderContributionCell(day.count)}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-medium mb-4 text-white dark:text-slate-800">Recent Repositories</h4>
                      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                        {githubData.recentRepos.map((repo, index) => (
                          <motion.div
                            key={index}
                            className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg hover:bg-[#0F1C36] dark:hover:bg-slate-200 transition-colors duration-300 cursor-pointer"
                            whileHover={{ scale: 1.02 }}
                          >
                            <div className="flex justify-between items-start mb-2">
                              <a
                                href={repo.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sky-400 font-medium hover:underline flex items-center"
                              >
                                {repo.name}
                                <ExternalLink className="h-3 w-3 ml-1" />
                              </a>
                              <span className="text-xs text-gray-500 dark:text-slate-500">
                                Updated: {repo.updated_at}
                              </span>
                            </div>
                            <p className="text-gray-400 dark:text-slate-600 text-sm mb-3 line-clamp-2">
                              {repo.description}
                            </p>
                            <div className="flex flex-wrap items-center justify-between">
                              <div className="flex items-center">
                                <span
                                  className={`px-2 py-1 rounded-full text-xs ${getLanguageBadgeColor(repo.language)}`}
                                >
                                  {repo.language}
                                </span>
                              </div>
                              <div className="flex items-center space-x-4">
                                <div className="flex items-center">
                                  <svg className="w-4 h-4 text-yellow-400 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                                  </svg>
                                  <span className="text-gray-400 dark:text-slate-600 text-sm">{repo.stars}</span>
                                </div>
                                <div className="flex items-center">
                                  <svg
                                    className="w-4 h-4 text-gray-400 dark:text-slate-600 mr-1"
                                    fill="currentColor"
                                    viewBox="0 0 20 20"
                                  >
                                    <path
                                      fillRule="evenodd"
                                      d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z"
                                      clipRule="evenodd"
                                    ></path>
                                  </svg>
                                  <span className="text-gray-400 dark:text-slate-600 text-sm">{repo.forks}</span>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                </div>
              )}

              {/* WakaTime Tab */}
              {activeTab === "wakatime" && wakaTimeData && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Stats Card */}
                  <motion.div
                    className="bg-[#0A1428]/80 dark:bg-white/80 p-6 rounded-lg shadow-[0_0_15px_rgba(14,165,233,0.15)]"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <h3 className="text-xl font-semibold mb-6 text-white dark:text-slate-800 flex items-center">
                      <Clock className="h-5 w-5 mr-2 text-purple-400" />
                      Coding Stats
                    </h3>

                    <div className="grid grid-cols-1 gap-4">
                      <div className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg">
                        <p className="text-gray-400 dark:text-slate-600 text-sm">Total Coding Time</p>
                        <p className="text-2xl font-bold text-purple-400">{wakaTimeData.totalHours} hrs</p>
                      </div>
                      <div className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg">
                        <p className="text-gray-400 dark:text-slate-600 text-sm">Daily Average</p>
                        <p className="text-2xl font-bold text-purple-400">{wakaTimeData.dailyAverage} hrs</p>
                      </div>
                    </div>

                    <div className="mt-6">
                      <h4 className="text-lg font-medium mb-4 text-white dark:text-slate-800">Editors</h4>
                      <div className="space-y-3">
                        {wakaTimeData.editors.map((editor, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <span className="text-gray-400 dark:text-slate-600">{editor.name}</span>
                            <span className="text-purple-400 font-medium">{editor.percent}%</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-6">
                      <a
                        href="https://wakatime.com/@arindhimar"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center w-full py-2 bg-[#050A1C]/80 dark:bg-slate-100/80 text-purple-400 rounded-lg hover:bg-[#0F1C36] dark:hover:bg-slate-200 transition-colors duration-300"
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View WakaTime Profile
                      </a>
                    </div>
                  </motion.div>

                  {/* Languages and Weekly Activity */}
                  <motion.div
                    className="bg-[#0A1428]/80 dark:bg-white/80 p-6 rounded-lg shadow-[0_0_15px_rgba(14,165,233,0.15)] lg:col-span-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 }}
                  >
                    <h3 className="text-xl font-semibold mb-6 text-white dark:text-slate-800 flex items-center">
                      <Code className="h-5 w-5 mr-2 text-purple-400" />
                      Languages & Activity
                    </h3>

                    <div className="mb-8">
                      <h4 className="text-lg font-medium mb-4 text-white dark:text-slate-800">Languages</h4>
                      <div className="mb-2">{renderLanguageBar(wakaTimeData.languages)}</div>
                      <div className="flex flex-wrap gap-4 mt-4">
                        {wakaTimeData.languages.map((lang, index) => (
                          <div key={index} className="flex items-center">
                            <div
                              className="w-3 h-3 rounded-full mr-2"
                              style={{ background: getLanguageColor(lang.name) }}
                            ></div>
                            <span className="text-gray-400 dark:text-slate-600 text-sm">
                              {lang.name} ({lang.percent}%)
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-medium mb-4 text-white dark:text-slate-800 flex items-center">
                        <Activity className="h-4 w-4 mr-2 text-purple-400" />
                        Weekly Activity
                      </h4>
                      <div className="bg-[#050A1C]/80 dark:bg-slate-100/80 p-4 rounded-lg">
                        <div className="flex items-end justify-between h-40">
                          {wakaTimeData.weeklyActivity.map((day, index) => (
                            <div key={index} className="flex flex-col items-center">
                              <div
                                className="w-8 bg-gradient-to-t from-purple-600 to-blue-500 rounded-t-md hover:from-purple-500 hover:to-blue-400 transition-colors duration-300 relative group"
                                style={{ height: `${(day.hours / 8) * 100}%` }}
                              >
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#0A1428] dark:bg-white text-white dark:text-slate-800 text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap pointer-events-none">
                                  {day.hours} hrs
                                </div>
                              </div>
                              <span className="text-xs text-gray-500 dark:text-slate-500 mt-2">
                                {day.day.substring(0, 3)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </div>
    </section>
  )
}

export default GithubActivity
