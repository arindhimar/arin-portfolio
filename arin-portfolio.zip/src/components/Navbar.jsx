"use client"

import { useState, useEffect } from "react"
import { Menu, X, Github, Linkedin, Instagram, Moon, Sun } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useTheme } from "@/components/ThemeProvider"

const Navbar = ({ activeSection, onSectionChange }) => {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    // Close mobile menu when clicking outside
    const handleClickOutside = (event) => {
      if (isOpen && !event.target.closest(".mobile-menu") && !event.target.closest(".menu-button")) {
        setIsOpen(false)
      }
    }

    // Prevent scrolling when mobile menu is open
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "auto"
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
      document.body.style.overflow = "auto"
    }
  }, [isOpen])

  const toggleMenu = () => setIsOpen(!isOpen)

  // Simplified navigation links
  const navLinks = [
    { name: "Home", id: "home" },
    { name: "Skills", id: "skills" },
    { name: "Projects", id: "projects" },
    { name: "GitHub", id: "github-activity" },
    { name: "Achievements", id: "achievements" },
  ]

  const socialLinks = [
    {
      name: "GitHub",
      href: "https://github.com/arindhimar",
      icon: <Github className="h-5 w-5" />,
    },
    {
      name: "LinkedIn",
      href: "https://linkedin.com/in/arin-dhimar",
      icon: <Linkedin className="h-5 w-5" />,
    },
    {
      name: "Instagram",
      href: "https://instagram.com/arin_dhimar_/",
      icon: <Instagram className="h-5 w-5" />,
    },
  ]

  const handleNavClick = (id) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      onSectionChange(id)
      if (isOpen) setIsOpen(false)
    }
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#050A1C]/80 dark:bg-slate-100/80 backdrop-blur-md border-b border-violet-500/20"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0 flex items-center">
            <button
              onClick={() => handleNavClick("home")}
              className="text-xl font-bold bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent hover:scale-105 transition-transform duration-300"
            >
              Arin Dhimar
            </button>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              {navLinks.map((link) => (
                <Button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  variant={activeSection === link.id ? "ghost2" : "ghost"}
                  className={`relative ${
                    activeSection === link.id
                      ? "text-violet-400 dark:text-violet-600"
                      : "text-gray-300 dark:text-slate-700"
                  }`}
                >
                  {link.name}
                  {activeSection === link.id && (
                    <motion.span
                      layoutId="activeSection"
                      className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-violet-400 to-fuchsia-400"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    ></motion.span>
                  )}
                </Button>
              ))}
            </div>

            <div className="flex items-center space-x-2 ml-4">
              {socialLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 dark:text-slate-600 hover:text-violet-400 dark:hover:text-violet-600 transition-all duration-300 p-2"
                  aria-label={link.name}
                >
                  {link.icon}
                </a>
              ))}

              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="ml-2 text-gray-400 dark:text-slate-600 hover:text-violet-400 dark:hover:text-violet-600"
                aria-label="Toggle theme"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            </div>
          </div>

          <div className="flex md:hidden items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="text-gray-400 dark:text-slate-600"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMenu}
              aria-expanded={isOpen ? "true" : "false"}
              aria-label="Toggle menu"
              className="text-gray-400 dark:text-slate-600 menu-button"
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "100vh" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden overflow-hidden fixed inset-0 top-16 mobile-menu"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-[#050A1C]/95 dark:bg-slate-100/95 backdrop-blur-lg h-full flex flex-col">
              <div className="flex-1">
                {navLinks.map((link, index) => (
                  <motion.div
                    key={link.id}
                    initial={{ x: -50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1, duration: 0.3 }}
                    className="px-3 py-2"
                  >
                    <Button
                      onClick={() => handleNavClick(link.id)}
                      variant={activeSection === link.id ? "ghost2" : "ghost"}
                      className={`w-full justify-start ${
                        activeSection === link.id
                          ? "text-violet-400 dark:text-violet-600"
                          : "text-gray-300 dark:text-slate-700"
                      }`}
                    >
                      {link.name}
                    </Button>
                  </motion.div>
                ))}
              </div>

              <div className="flex justify-center space-x-4 px-3 py-4 border-t border-violet-500/20 mt-auto">
                {socialLinks.map((link, index) => (
                  <motion.a
                    key={link.name}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-400 dark:text-slate-600 hover:text-violet-400 dark:hover:text-violet-600 transition-all duration-300 p-2"
                    aria-label={link.name}
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 + index * 0.1, duration: 0.3 }}
                  >
                    {link.icon}
                  </motion.a>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}

export default Navbar
